import Image from "next/image";
import "./about.css";

//import ms from "../../../public/assets/ms.jpg";

const About = () => {
  return (
    <section id="about" className={""}>
      <div className={"identity"}>
        <div className={"about"}></div>

        <div className={""}>
          <p className={""}>Обо мне</p>
          <h2 className={""}>Селиванова Мария Сергеевна</h2>
          <p className={""}>Врач-косметолог, врач высшей категории</p>

          <p className={""}>
            Стаж работы в медицине — 15 лет. За это время сформировался принцип,
            которого придерживаюсь в работе: перед любой процедурой — осмотр и
            честный разговор о том, что действительно нужно именно вашей коже, а
            не навязанный список услуг.
          </p>

          <div className={""}>
            <div className={""}>
              <span className={""}>15 лет</span>
              <span className={""}>стажа в медицине</span>
            </div>
            <div className={""}>
              <span className={""}>Высшая</span>
              <span className={""}>врачебная категория</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
